.. _reference.feed.author:

:py:attr:`feed.author`
======================

The author of this feed.


.. rubric:: Comes from

* /atom03:feed/atom03:author
* /atom10:feed/atom10:author
* /rdf:RDF/rdf:channel/dc:author
* /rdf:RDF/rdf:channel/dc:creator
* /rss/channel/dc:author
* /rss/channel/dc:creator
* /rss/channel/itunes:author
* /rss/channel/managingEditor


.. seealso::

    * :ref:`reference.feed.author_detail`
